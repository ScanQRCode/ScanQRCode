Build:
	yarn run build
framework  https://github.com/abhijithvijayan/web-extension-starter

ScanQRCode can scanning QR code in every page. Support scanning QR code via webcam and webpage screenshot.
安装插件后需要刷新页面或重启浏览器以启用所有功能