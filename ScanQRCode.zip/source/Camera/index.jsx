import * as React from 'react';
import ReactDOM from 'react-dom';

import Camera from './Camera.jsx';

ReactDOM.render(<Camera />, document.getElementById('camera-root'));
