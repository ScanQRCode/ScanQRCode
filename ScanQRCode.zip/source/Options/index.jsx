import * as React from 'react';
import ReactDOM from 'react-dom';

import Options from './Options.jsx';

ReactDOM.render(<Options />, document.getElementById('options-root'));
