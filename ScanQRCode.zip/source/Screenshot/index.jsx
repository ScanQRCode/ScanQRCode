import * as React from 'react';
import ReactDOM from 'react-dom';

import Screenshot from './Screenshot.jsx';

ReactDOM.render(<Screenshot />, document.getElementById('screenshot-root'));
